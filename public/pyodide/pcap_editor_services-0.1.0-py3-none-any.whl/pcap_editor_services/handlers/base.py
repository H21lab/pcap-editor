from models import Layer
from utils.pycrate_utils import pycrate_to_fields

class PycrateDissector:
    def create_layer(self, inst, name, ctx, idx, offset):
        l = Layer(
            index=idx,
            name=f"{name} (Pycrate)",
            protocol=name,
            fields=pycrate_to_fields(inst),
            offset=offset,
            length=len(inst.to_ber()) if hasattr(inst, 'to_ber') else (len(inst.to_bytes()) if hasattr(inst, 'to_bytes') else 0),
            source="pycrate"
        )
        ctx.register_instance(idx, inst, offset)
        return l
