from typing import Dict, List, Any, Optional
from models import Layer

class DissectionContext:
    """
    Holds the state of a single packet's dissection or edit session.
    Prevents global state pollution and enables easier testing.
    """
    def __init__(self, hex_data: str, pkt_id: Optional[str] = None, ws_layers: List[str] = None):
        self.pkt_id = pkt_id or hex_data
        self.original_hex = hex_data
        self.ws_layers = ws_layers or []
        self.layers: List[Layer] = []
        # Maps index -> (instance, offset)
        self.instances: Dict[int, Any] = {}
        self.command: str = ""

    def register_instance(self, index: int, inst: Any, offset: int):
        self.instances[index] = (inst, offset)

    def get_instance(self, index: int):
        return self.instances.get(index)
