import binascii
import textwrap
import copy
import pprint
import builtins
from scapy.all import Ether, IP, SCTP, Raw, NoPayload, Packet
from models import Layer, ModelField, DissectionResult
from context import DissectionContext
from handlers.scapy_handler import ScapyDissector, PYCRATE_LAYERS, TelcoLayer
from scapy_ext import reconstruct

class DissectionEngine:
    def __init__(self, dissectors):
        self.dissectors = dissectors
        builtins.pycrate_encode = self.pycrate_encode
        builtins.pycrate_sync = self.pycrate_sync

    def dissect(self, hex_data: str, pkt_id: str, ws_layers: list = None) -> DissectionResult:
        ctx = DissectionContext(hex_data, pkt_id, ws_layers)
        ctx.layers = ScapyDissector().dissect_hex(hex_data)
        self._deep_dissect(ctx)
        
        command = ""
        try:
            pkt = reconstruct(hex_data)
            py_layers_info = [l for l in ctx.layers if l.source == "pycrate"]
            
            last_scapy = pkt
            while not isinstance(last_scapy.payload, (NoPayload, Raw)):
                last_scapy = last_scapy.payload
            
            if hasattr(last_scapy, 'data') and last_scapy.name == "SCTPChunkData":
                last_scapy.data = b""
            last_scapy.payload = NoPayload()
            
            scapy_cmd = pkt.command().replace(chr(0), '')
            assignments = []
            stack_parts = [scapy_cmd]
            
            for pl in py_layers_info:
                inst_data = ctx.get_instance(pl.index)
                if inst_data:
                    val = inst_data[0].get_val()
                    clean_proto = pl.protocol.replace("/", "_").replace("-", "_")
                    var_name = f"{clean_proto.lower()}_val"
                    assignments.append(f"{var_name} = {pprint.pformat(val, indent=2, width=80)}")
                    
                    cls = PYCRATE_LAYERS.get(pl.protocol)
                    if not cls:
                        cls_name = clean_proto.upper()
                        cls = type(cls_name, (TelcoLayer,), {"name": pl.name})
                        PYCRATE_LAYERS[pl.protocol] = cls
                        setattr(builtins, cls_name, cls)
                    
                    stack_parts.append(f"{cls.__name__}(pycrate_val={var_name})")

            command = "\n".join(assignments) + "\n\n"
            command += "pkt = " + " / ".join(stack_parts)
            
            if ctx.instances:
                command += "\n\n# --- Pycrate ASN.1 Reference ---"
                for idx, (inst, _) in sorted(ctx.instances.items()):
                    layer_info = next((l for l in ctx.layers if l.index == idx), None)
                    if layer_info and hasattr(inst, 'to_asn1'):
                        command += f"\n# {layer_info.name}:\n" + textwrap.indent(inst.to_asn1(), "# ")
        except Exception as e:
            command = f"# Error building command: {e}"

        warnings = self._check_consistency(ctx)
        return DissectionResult(ctx.layers, command, consistency_warnings=warnings)

    def pycrate_sync(self, pkt):
        l_list = []
        curr = pkt
        while curr and not isinstance(curr, NoPayload):
            l_list.append(curr)
            curr = curr.payload
            
        for i in range(len(l_list)-1, 0, -1):
            child = l_list[i]; parent = l_list[i-1]
            if hasattr(child, 'pycrate_val') and child.pycrate_val is not None:
                if hasattr(parent, 'pycrate_val') and parent.pycrate_val is not None:
                    child_bin = self.pycrate_encode(child.__class__.__name__, child.pycrate_val)
                    if child_bin: self._pycrate_inject(parent.__class__.__name__, parent.pycrate_val, child_bin)

    def _pycrate_inject(self, parent_name, parent_val, child_bin):
        try:
            if "M3UA" in parent_name:
                params = parent_val[1] if isinstance(parent_val, list) and len(parent_val) > 1 else []
                for p in params:
                    if p[0] == 528:
                        p[2][6] = child_bin; return True
            elif "SCCP" in parent_name:
                if isinstance(parent_val[-1], list) and len(parent_val[-1]) == 2:
                    parent_val[-1][1] = child_bin
                else: parent_val[-1] = child_bin
                return True
        except: pass
        return False

    def pycrate_encode(self, protocol_name, value):
        if value is None: return b""
        try:
            val_copy = copy.deepcopy(value)
            if "M3UA" in protocol_name:
                from pycrate_mobile.M3UA import M3UA_DATA
                inst = M3UA_DATA()
                if isinstance(val_copy, list) and len(val_copy) > 1:
                    inst[0].set_val(val_copy[0])
                    inst[1].set_val(val_copy[1])
                else: inst.set_val(val_copy)
                return inst.to_bytes()
            if "SCCP" in protocol_name:
                from pycrate_mobile.SCCP import SCCPMessage
                inst = SCCPMessage(); inst.set_val(val_copy); return inst.to_bytes()
            if "TCAP" in protocol_name or "MAP" in protocol_name:
                from pycrate_asn1dir import TCAP_MAPv2v3
                inst = copy.deepcopy(TCAP_MAPv2v3.TCAP_MAP_Messages.TCAP_MAP_Message)
                inst.set_val(val_copy); return inst.to_ber()
            if "GTP" in protocol_name:
                from pycrate_mobile.TS29060_GTP import GTP
                inst = GTP(); inst.set_val(val_copy); return inst.to_bytes()
        except Exception as e: 
            pass
        return b""

    def _check_consistency(self, ctx: DissectionContext) -> list:
        if not ctx.ws_layers: return []
        detected = [l.protocol.lower() for l in ctx.layers]
        S = {"m3ua": ["m3ua"], "sccp": ["sccp"], "tcap": ["tcap", "tcap/map"], "map": ["map", "gsm_map"], "gtp": ["gtp"]}
        w = []
        for wl in ctx.ws_layers:
            if wl.lower() in ['frame', 'eth', 'sctp.checksum']: continue
            if not any(t in detected for t in S.get(wl.lower(), [wl.lower()])):
                w.append(f"Protocol '{wl}' missing in Python engine.")
        return w

    def _deep_dissect(self, ctx: DissectionContext):
        while ctx.layers and ctx.layers[-1].protocol == "Raw":
            raw_layer = ctx.layers.pop()
            payload = binascii.unhexlify(raw_layer.find_field("load").value)
            progress = False
            _WS_TO_PYCRATE = globals().get('WS_TO_PYCRATE', {})
            ws_hint = None
            if ctx.ws_layers:
                for wl in ctx.ws_layers:
                    if wl.lower() in _WS_TO_PYCRATE:
                        ws_hint = _WS_TO_PYCRATE[wl.lower()]; break
            for handler in sorted(self.dissectors, key=lambda d: d.__class__.__name__ != ws_hint):
                try:
                    if handler.check(payload, ctx):
                        new_layers, consumed = handler.dissect(payload, ctx, raw_layer.index)
                        if new_layers:
                            ctx.layers.extend(new_layers)
                            if len(payload) > consumed:
                                leftover = payload[consumed:]
                                ctx.layers.append(Layer(index=ctx.layers[-1].index + 1, name="Raw", protocol="Raw", fields=[ModelField("load", leftover.hex(), "Raw")]))
                            progress = True; break
                except Exception: continue
            if not progress: ctx.layers.append(raw_layer); break
