from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class GsmADissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() in ['gsm_a', 'gsm_a_dtap'] for l in ctx.ws_layers): return True
        return False

    def dissect(self, data, ctx, idx):
        return None, 0
