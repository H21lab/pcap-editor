import binascii
from scapy.all import Ether, Raw, IP, NoPayload
from scapy.layers.sctp import SCTP, SCTPChunkData
from utils.pycrate_utils import convert_value

class Patcher:
    @staticmethod
    def apply_edits(ctx, edits):
        orig_bytes = binascii.unhexlify(ctx.original_hex)
        if not edits: return orig_bytes

        pkt = Ether(orig_bytes)
        for cls in [Ether, IP, SCTP]:
            try:
                p = cls(orig_bytes)
                if len(p) > 10: pkt = p; break
            except: pass
            
        if pkt.haslayer(SCTP):
            s = pkt.getlayer(SCTP)
            if isinstance(s.payload, Raw):
                try: s.payload = SCTPChunkData(s.payload.load)
                except: pass
        
        changed = False
        for ed in edits:
            inst_data = ctx.get_instance(ed['layer_index'])
            if inst_data:
                inst, start = inst_data
                path = ed['field'].split('.')
                ppath = [int(p) if p.isdigit() else p for p in path]
                
                try: node_type = type(inst.get_at(ppath)).__name__
                except: node_type = "Unknown"
                
                val = convert_value(node_type, ed['value'])
                
                def upd(obj, pts, nv):
                    if not pts: return nv
                    k = pts[0]
                    if isinstance(obj, dict): obj[k] = upd(obj.get(k), pts[1:], nv)
                    elif isinstance(obj, (list, tuple)):
                        l = list(obj); target = k if isinstance(k, int) else 0
                        if not isinstance(k, int) and len(l) == 2 and l[0] == k: target = 1
                        l[target] = upd(l[target], pts[1:], nv)
                        return tuple(l) if isinstance(obj, tuple) else l
                    return obj
                
                inst.set_val(upd(inst.get_val(), ppath, val))
                if hasattr(inst, 'to_ber'):
                    new_ber = inst.to_ber()
                elif hasattr(inst, 'to_bytes'):
                    new_ber = inst.to_bytes()
                else:
                    new_ber = bytes(inst)
                
                if pkt.haslayer(SCTPChunkData):
                    chunk = pkt.getlayer(SCTPChunkData)
                    old_payload = bytes(chunk.data)
                    chunk.data = old_payload[:start] + new_ber
                    if hasattr(chunk, 'len'): del chunk.len
                else:
                    last = pkt.lastlayer()
                    if hasattr(last, 'data'): last.data = bytes(last.data)[:start] + new_ber
                    else: last.payload = Raw(new_ber)
                changed = True
        
        if changed:
            curr = pkt
            while curr:
                for f in ['chksum', 'len', 'length', 'cksum', 'datalen', 'crc']:
                    if hasattr(curr, f):
                        try: setattr(curr, f, None)
                        except: pass
                if isinstance(curr.payload, NoPayload): break
                curr = curr.payload
            return bytes(pkt.__class__(bytes(pkt)))
        return orig_bytes
