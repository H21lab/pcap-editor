from pycrate_mobile.M3UA import parse_M3UA
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class M3UADissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() == 'm3ua' for l in ctx.ws_layers): return True
        for off in range(min(32, len(data) - 4)):
            if data[off] == 1 and data[off+1] == 0 and data[off+2] == 1:
                return True
        return False

    def dissect(self, data, ctx, idx):
        m, err, off = None, None, 0
        for try_off in range(min(32, len(data) - 4)):
            if data[try_off] == 1 and data[try_off+1] == 0 and data[try_off+2] == 1:
                m, err = parse_M3UA(data[try_off:])
                if not err:
                    off = try_off; break
        
        if not m or err: return None, 0
            
        layer = self.create_layer(m, "M3UA", ctx, idx, off)
        res_layers = [layer]
        
        sccp_data = None
        try:
            val = m.get_val()
            if len(val) > 1 and isinstance(val[1], list):
                for p in val[1]:
                    if isinstance(p, list) and len(p) >= 3 and p[0] == 528: # Protocol Data
                        if isinstance(p[2], list) and len(p[2]) >= 7:
                            sccp_data = p[2][6]
                            break
        except: pass

        if sccp_data:
            if isinstance(sccp_data, (list, tuple)): sccp_data = bytes(sccp_data)
            from handlers.sccp_handler import SCCPDissector
            s_layers, _ = SCCPDissector().dissect(sccp_data, ctx, idx + len(res_layers))
            if s_layers: res_layers.extend(s_layers)
        
        return res_layers, len(data)
