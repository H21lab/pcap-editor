from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class PfcpDissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() == 'pfcp' for l in ctx.ws_layers): return True
        return len(data) > 8 and (data[0] >> 5) == 1

    def dissect(self, data, ctx, idx):
        # Placeholder, as the pycrate pfcp module was not found
        return None, 0
