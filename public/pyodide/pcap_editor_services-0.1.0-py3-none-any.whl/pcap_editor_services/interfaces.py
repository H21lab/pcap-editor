from abc import ABC, abstractmethod
from typing import List, Optional, Tuple
from models import Layer
from context import DissectionContext

class Dissector(ABC):
    @abstractmethod
    def check(self, data: bytes, ctx: DissectionContext) -> bool:
        pass
    
    @abstractmethod
    def dissect(self, data: bytes, ctx: DissectionContext, current_idx: int) -> Tuple[Optional[List[Layer]], int]:
        pass
