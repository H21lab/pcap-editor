import importlib
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class GenericPycrateDissector(PycrateDissector):
    def check(self, data, ctx):
        from registry import WS_TO_PYCRATE
        for wl in ctx.ws_layers:
            if WS_TO_PYCRATE.get(wl.lower()) == "GenericPycrateDissector":
                return True
        return False

    def dissect(self, data, ctx, idx):
        DYNAMIC_MAP = {
            "isup": ("pycrate_mobile.ISUP", "ISUPMessage"),
            # Add other generic mappings here
        }
        
        target = None
        for wl in ctx.ws_layers:
            if wl.lower() in DYNAMIC_MAP:
                target = DYNAMIC_MAP[wl.lower()]
                break
        
        if not target: return None, 0
        
        try:
            mod_name, class_name = target
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, class_name)
            inst = cls()
            if hasattr(inst, 'from_bytes'):
                inst.from_bytes(data)
            elif hasattr(inst, 'from_ber'):
                inst.from_ber(data)
            else:
                return None, 0
                
            layer = self.create_layer(inst, wl.upper(), ctx, idx, 0)
            return [layer], len(data)
        except Exception as e:
            return None, 0
