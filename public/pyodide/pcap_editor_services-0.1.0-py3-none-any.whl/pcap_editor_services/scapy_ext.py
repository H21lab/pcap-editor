import binascii
from scapy.all import Ether, CookedLinux, IP, Raw, NoPayload
from scapy.layers.sctp import SCTP, SCTPChunkData

def reconstruct(hex_data):
    """Reconstruct a Scapy packet with forced dissection of known encapsulations."""
    data = binascii.unhexlify(hex_data)
    pkt = Ether(data) # Default fallback

    # Try various base layers
    for cls in [Ether, CookedLinux, IP]:
        try:
            p = cls(data)
            if len(p) > 10: # A somewhat arbitrary threshold for a 'valid' dissection
                pkt = p
                break
        except:
            pass

    # Force SCTP dissection if present, especially for Raw payloads
    if pkt.haslayer("SCTP"):
        sctp_layer = pkt.getlayer(SCTP)
        if isinstance(sctp_layer.payload, Raw):
            try:
                sctp_layer.payload = SCTPChunkData(sctp_layer.payload.load)
            except:
                pass
    return pkt
