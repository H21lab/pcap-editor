from pycrate_mobile.SCCP import parse_SCCP
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class SCCPDissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() == 'sccp' for l in ctx.ws_layers): return True
        return len(data) > 0 and data[0] in (0x09, 0x11, 0x12)

    def dissect(self, data, ctx, idx):
        try:
            s, err = parse_SCCP(data)
            if err: return None, 0
                
            layer = self.create_layer(s, "SCCP", ctx, idx, 0)
            res_layers = [layer]
            
            tcap_data = None
            try:
                val = s.get_val()
                if isinstance(val, list):
                    last = val[-1]
                    if isinstance(last, list) and len(last) == 2 and isinstance(last[1], bytes):
                        tcap_data = last[1]
                    elif isinstance(last, bytes):
                        tcap_data = last
                    elif isinstance(last, dict):
                        tcap_data = last.get('Data')
            except: pass
            
            if not tcap_data:
                for i in range(len(data) - 4):
                    if data[i] == 0x62: # TCAP Begin
                        tcap_data = data[i:]; break
            
            if tcap_data:
                if isinstance(tcap_data, (list, tuple)): tcap_data = bytes(tcap_data)
                from handlers.tcap_map_handler import TcapMapDissector
                t_layers, _ = TcapMapDissector().dissect(tcap_data, ctx, idx + len(res_layers))
                if t_layers: res_layers.extend(t_layers)
                    
            return res_layers, len(data)
        except: return None, 0
