import copy
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class ApDissector(PycrateDissector):
    def check(self, data, ctx):
        return any(l.lower() in ['s1ap', 'ngap', 'x2ap', 'f1ap', 'e1ap', 'ranap'] for l in ctx.ws_layers)

    def dissect(self, data, ctx, idx):
        ap_module = None
        name = "AP"
        
        for wl in ctx.ws_layers:
            wl_lower = wl.lower()
            if 's1ap' in wl_lower:
                from pycrate_asn1dir import S1AP
                ap_module = S1AP.S1AP_PDU_Descriptions.S1AP_PDU
                name = "S1AP"
                break
            elif 'ngap' in wl_lower:
                from pycrate_asn1dir import NGAP
                ap_module = NGAP.NGAP_PDU_Descriptions.NGAP_PDU
                name = "NGAP"
                break
            # Add other APs here as needed...

        if not ap_module: return None, 0
        
        try:
            inst = copy.deepcopy(ap_module)
            inst.from_ber(data)
            layer = self.create_layer(inst, name, ctx, idx, 0)
            return [layer], len(data)
        except:
            return None, 0
