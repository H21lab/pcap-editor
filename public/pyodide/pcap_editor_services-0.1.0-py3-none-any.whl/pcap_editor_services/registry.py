from typing import List, Type, Dict, Any, Callable
from interfaces import Dissector

DISSECTORS = []

WS_TO_PYCRATE = {
    # SIGTRAN / SS7
    "m3ua": "M3UADissector",
    "sccp": "SCCPDissector",
    "tcap": "TcapMapDissector",
    "map": "TcapMapDissector",
    "gsm_map": "TcapMapDissector",
    "cap": "TcapMapDissector",
    "camel": "TcapMapDissector",
    "isup": "GenericPycrateDissector",
    
    # 4G / 5G Core
    "gtp": "GTPDissector",
    "gtpv2": "GTPDissector",
    "diameter": "DiameterDissector",
    "pfcp": "PfcpDissector",
    "nas_5gs": "NasDissector",
    "nas-5gs": "NasDissector",
    "nas_eps": "NasDissector",
    "nas-eps": "NasDissector",
    
    # Application Parts (Generic AP Handler)
    "s1ap": "ApDissector",
    "ngap": "ApDissector",
    "x2ap": "ApDissector",
    "f1ap": "ApDissector",
    "e1ap": "ApDissector",
    "m2ap": "ApDissector",
    "m3ap": "ApDissector",
    "ranap": "ApDissector",
    "hnbap": "ApDissector",
    "rua": "ApDissector",
    "xnap": "ApDissector",
    
    # RAN / Radio
    "nr-rrc": "GenericPycrateDissector",
    "lte-rrc": "GenericPycrateDissector",
    "rrc": "GenericPycrateDissector",
    "lpp": "GenericPycrateDissector",
    "lppa": "GenericPycrateDissector",
    "lppe": "GenericPycrateDissector",
    "bssap": "GenericPycrateDissector",
    "bssmap": "GenericPycrateDissector",
    
    # Others
    "gsm_a": "GsmADissector",
    "gsm_a_dtap": "GsmADissector",
    "gsm_sms": "GenericPycrateDissector",
    "h248": "GenericPycrateDissector",
    "megaco": "GenericPycrateDissector",
    "snmp": "GenericPycrateDissector",
    "ldap": "GenericPycrateDissector"
}

def register_dissector(cls: Type[Dissector]):
    if cls not in DISSECTORS:
        DISSECTORS.append(cls)
    return cls

def get_dissectors() -> List[Type[Dissector]]:
    return DISSECTORS

def load_handlers():
    from handlers import m3ua_handler, sccp_handler, tcap_map_handler, gtp_handler, gsm_a_handler, nas_handler, ap_handler, diameter_handler, pfcp_handler, generic_pycrate_handler
