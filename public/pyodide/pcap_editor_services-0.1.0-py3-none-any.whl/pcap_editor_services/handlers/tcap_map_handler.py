import copy
from pycrate_asn1dir import TCAP_MAPv2v3
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class TcapMapDissector(PycrateDissector):
    def check(self, data: bytes, ctx) -> bool:
        if any(l.lower() in ['tcap', 'map', 'gsm_map', 'cap', 'camel'] for l in ctx.ws_layers): return True
        return len(data) > 0 and data[0] == 0x62

    def dissect(self, data, ctx, current_idx):
        if any('cap' in l.lower() or 'camel' in l.lower() for l in ctx.ws_layers):
            try:
                from pycrate_asn1dir import CAP
                inst = copy.deepcopy(CAP.CAP_gsmSSF_gsmSCF_Messages.CAP_GsmSSF_GsmSCF_Message)
                inst.from_ber(data)
                layer = self.create_layer(inst, "CAP", ctx, current_idx, 0)
                return [layer], len(data)
            except: pass

        try:
            tm = copy.deepcopy(TCAP_MAPv2v3.TCAP_MAP_Messages.TCAP_MAP_Message)
            tm.from_ber(data)
            layer = self.create_layer(tm, "TCAP/MAP", ctx, current_idx, 0)
            return [layer], len(data)
        except:
            return None, 0
