from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class DiameterDissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() == 'diameter' for l in ctx.ws_layers): return True
        return len(data) > 4 and data[0] == 0x01

    def dissect(self, data, ctx, idx):
        # Placeholder, as the pycrate diameter module was not found
        return None, 0
