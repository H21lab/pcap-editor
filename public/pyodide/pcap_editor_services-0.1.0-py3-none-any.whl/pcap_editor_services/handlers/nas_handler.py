from pycrate_mobile.NASLTE import parse_NASLTE_MO
from pycrate_mobile.NAS5G import parse_NAS5G
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class NasDissector(PycrateDissector):
    def check(self, data, ctx):
        return any(l.lower() in ['nas_5gs', 'nas-5gs', 'nas_eps', 'nas-eps'] for l in ctx.ws_layers)

    def dissect(self, data, ctx, idx):
        is_5g = any('5gs' in l.lower() for l in ctx.ws_layers)
        try:
            nas, err = None, None
            if is_5g:
                nas, err = parse_NAS5G(data)
            else:
                nas, err = parse_NASLTE_MO(data)
            
            if err:
                if is_5g: nas, err = parse_NASLTE_MO(data)
                else: nas, err = parse_NAS5G(data)
            
            if err: return None, 0
            
            layer = self.create_layer(nas, "NAS", ctx, idx, 0)
            return [layer], len(data)
        except:
            return None, 0
