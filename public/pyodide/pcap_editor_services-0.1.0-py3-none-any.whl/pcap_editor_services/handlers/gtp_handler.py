from pycrate_mobile.TS29060_GTP import parse_GTP
from pycrate_mobile.TS29274_GTPC import parse_GTPC
from pycrate_mobile.TS29281_GTPU import parse_GTPU
from handlers.base import PycrateDissector
from registry import register_dissector

@register_dissector
class GTPDissector(PycrateDissector):
    def check(self, data, ctx):
        if any(l.lower() == 'gtp' for l in ctx.ws_layers): return True
        if len(data) < 8: return False
        v = (data[0] >> 5) & 0x7
        return v in (1, 2)

    def dissect(self, data, ctx, idx):
        try:
            v = (data[0] >> 5) & 0x7
            gtp, err = None, None
            if v == 1:
                gtp, err = parse_GTPU(data)
                if err: gtp, err = parse_GTP(data)
            elif v == 2:
                gtp, err = parse_GTPC(data)
            
            if err or not gtp: return None, 0
            
            layer = self.create_layer(gtp, "GTP", ctx, idx, 0)
            res_layers = [layer]
            
            payload = None
            try:
                gv = gtp.get_val()
                if isinstance(gv, list) and len(gv) > 1:
                    hdr = gv[0]; mtype = None
                    if isinstance(hdr, list) and len(hdr) > 1: mtype = hdr[1]
                    elif isinstance(hdr, dict): mtype = hdr.get('msg_type')
                    if mtype == 255: payload = gv[1]
            except: pass
                
            if payload:
                if isinstance(payload, (list, tuple)): payload = bytes(payload)
                from handlers.scapy_handler import ScapyDissector
                try:
                    inner = ScapyDissector().dissect_hex(payload.hex())
                    if inner:
                        for il in inner: il.index += idx + len(res_layers)
                        res_layers.extend(inner)
                except: pass

            return res_layers, len(data)
        except: return None, 0
