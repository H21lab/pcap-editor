import binascii, string
from typing import List, Any
from models import ModelField

def pycrate_to_fields(inst) -> List[ModelField]:
    """Universal Pycrate field extractor."""
    fields = []
    # Strategy 1: Native paths
    if hasattr(inst, 'get_val_paths'):
        try:
            paths = inst.get_val_paths()
            for path, val in paths:
                name = ".".join(str(p) for p in path)
                try: 
                    node = inst.get_at(path)
                    type_name = type(node).__name__
                except: type_name = "Unknown"
                val_str = val.hex() if isinstance(val, (bytes, bytearray)) else str(val)
                fields.append(ModelField(name=name, value=val_str, type=type_name))
            if fields: return fields
        except: pass
    
    # Strategy 2: Value recursion
    try:
        val = inst.get_val()
        def rec(v, p=""):
            res = []
            if isinstance(v, dict):
                for k, sv in v.items(): res.extend(rec(sv, p + str(k) + "."))
            elif isinstance(v, (list, tuple)):
                if len(v) == 2 and isinstance(v[0], str): 
                    res.extend(rec(v[1], p + v[0] + "."))
                else:
                    for i, sv in enumerate(v): res.extend(rec(sv, p + "[" + str(i) + "]."))
            else:
                vs = v.hex() if isinstance(v, (bytes, bytearray)) else str(v)
                res.append(ModelField(name=p.rstrip('.'), value=vs, type=type(v).__name__))
            return res
        return rec(val)
    except:
        return []

def convert_value(node_type: str, raw_value: str) -> Any:
    """Standardized type conversion for Pycrate fields."""
    if any(x in node_type for x in ['OCT', 'STR', 'OID']):
        return binascii.unhexlify(raw_value)
    if any(x in node_type for x in ['INT', 'ENUM']):
        return int(raw_value)
    return raw_value
