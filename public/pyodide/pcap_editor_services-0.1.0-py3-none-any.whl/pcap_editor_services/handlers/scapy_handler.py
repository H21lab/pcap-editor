import binascii
import json
import builtins
from scapy.all import Ether, CookedLinux, IP, Raw, NoPayload, Packet, bind_layers, Field, StrField
from scapy.layers.sctp import SCTP, SCTPChunkData
from models import Layer, ModelField
from scapy_ext import reconstruct

class TelcoLayer(Packet):
    fields_desc = [
        StrField("pycrate_val_repr", "", fmt="H") 
    ]
    
    def __init__(self, _pkt=None, pycrate_val=None, **kwargs):
        self.pycrate_val = pycrate_val
        super().__init__(_pkt, **kwargs)

    def do_build(self):
        if self.pycrate_val is None: return b""
        encoder = getattr(builtins, "pycrate_encode", None)
        if encoder:
            return encoder(self.__class__.__name__, self.pycrate_val)
        return b""

class M3UA(TelcoLayer): name = "M3UA"
class SCCP(TelcoLayer): name = "SCCP"
class TCAP(TelcoLayer): name = "TCAP"
# ... and so on for all other layers

PYCRATE_LAYERS = {
    "M3UA": M3UA, "SCCP": SCCP, "TCAP": TCAP, "TCAP/MAP": TCAP, 
    # ...
}

class ScapyDissector:
    def dissect_hex(self, hex_data: str):
        pkt = reconstruct(hex_data)
        layers = []
        current = pkt
        idx = 0
        
        while current and not isinstance(current, NoPayload):
            if isinstance(current, Raw): break
            fields = []
            if hasattr(current, "fields_desc"):
                for f_desc in current.fields_desc:
                    try:
                        val = current.getfieldval(f_desc.name)
                        vs = val.hex() if isinstance(val, bytes) else str(val)
                        fields.append(ModelField(f_desc.name, vs, f_desc.__class__.__name__))
                    except: pass
                layers.append(Layer(idx, current.name, current.__class__.__name__, fields))
            current = current.payload
            idx += 1
            
        deep_payload = b""
        last_recognized = pkt
        if layers:
            for _ in range(len(layers) - 1): last_recognized = last_recognized.payload
        
        if last_recognized.name == "SCTPChunkData":
            sctp = pkt.getlayer(SCTP)
            if sctp: deep_payload = bytes(sctp)[12:]
        
        if not deep_payload:
            if not isinstance(last_recognized.payload, (NoPayload, Raw)):
                deep_payload = bytes(last_recognized.payload)
            elif isinstance(last_recognized.payload, Raw):
                deep_payload = bytes(last_recognized.payload)
            elif hasattr(last_recognized, 'load'):
                deep_payload = bytes(last_recognized.load)

        if deep_payload:
            start_off = 0
            while start_off < len(deep_payload) and deep_payload[start_off] == 0:
                start_off += 1
            if start_off < len(deep_payload):
                layers.append(Layer(idx, "Raw", "Raw", [ModelField("load", deep_payload[start_off:].hex(), "Raw")]))
            
        return layers
