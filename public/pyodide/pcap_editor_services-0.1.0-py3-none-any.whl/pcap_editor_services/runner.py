import textwrap, binascii, builtins
from scapy.all import Ether, IP, TCP, UDP, SCTP, Raw, NoPayload, Packet, bind_layers
from scapy.layers.sctp import SCTPChunkData
from scapy_ext import reconstruct
from handlers.scapy_handler import PYCRATE_LAYERS

class ScriptRunner:
    @staticmethod
    def run(hex_data: str, script: str) -> bytes:
        # Prepare execution environment
        safe_globals = {
            "__builtins__": builtins.__dict__,
            "binascii": binascii
        }
        
        try:
            # First exec creates the variables (m3ua_val, etc)
            exec(textwrap.dedent(script), safe_globals)
        except Exception as e:
            raise RuntimeError(f"Script execution failed: {type(e).__name__}: {str(e)}")
            
        res_pkt = safe_globals.get("pkt")
        if not res_pkt:
            raise RuntimeError("Script did not produce a 'pkt' variable.")
        
        # Sync Pycrate child layers to parents
        py_sync = getattr(builtins, "pycrate_sync", None)
        if py_sync:
            try: py_sync(res_pkt)
            except Exception as e: print(f"[ScriptRunner] Pycrate sync failed: {e}")

        # Recalculate and re-encode
        try:
            for l in res_pkt:
                for f in ['chksum', 'len', 'length', 'cksum', 'datalen', 'crc']:
                    if hasattr(l, f):
                        try: delattr(l, f)
                        except: pass
            
            return bytes(res_pkt.__class__(bytes(res_pkt)))
        except Exception as e:
            print(f"[ScriptRunner] Re-build failed: {e}")
            return bytes(res_pkt)
