from dataclasses import dataclass, field, asdict
from typing import List, Any, Optional

@dataclass
class ModelField:
    name: str; value: str; type: str; editable: bool = True

@dataclass
class Layer:
    index: int; name: str; protocol: str; fields: List[ModelField] = field(default_factory=list); offset: int = 0; length: int = 0; source: str = "scapy"
    def find_field(self, name: str) -> Optional[ModelField]:
        return next((f for f in self.fields if f.name == name), None)
    def to_dict(self): return asdict(self)

@dataclass
class DissectionResult:
    layers: List[Layer]; command: str; error: Optional[str] = None; consistency_warnings: List[str] = field(default_factory=list)
    def to_json(self):
        import json
        return json.dumps({
            "layers": [l.to_dict() for l in self.layers], 
            "command": self.command, 
            "error": self.error,
            "consistency_warnings": self.consistency_warnings
        })
